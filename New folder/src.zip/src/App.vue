<template>
  <router-view/>
</template>

<style>
.t{
  border: 1px solid red;
}

</style>